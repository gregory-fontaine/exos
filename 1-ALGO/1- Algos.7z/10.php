<?php
/* Quel resultat produit le programme suivant 
algoritme double; 
Var val, double : Entier;
Debut
    val <- 231;             val=231         double=?
    double <- val*2;        val=231         double= 462
    ecrire (val);
    ecrire (double);
    */

    echo 'Debut';
    echo PHP_EOL;
    $val = 231;
    $double = $val*2;
    echo $val;
    echo PHP_EOL;
    echo $double;
    echo PHP_EOL;
    echo 'Fin';


    /* le programme donne le double de la variable val */
?>