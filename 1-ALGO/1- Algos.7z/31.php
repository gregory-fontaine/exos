<?php
/*
Ecrire un algorithme qui déclare et remplisse un tableau contenant les six voyelles de l'alphabet latin.
*/

//on declare le tableau
$tab = array();
$tab[0] = 'A';
$tab[1] = 'E';
$tab[2] = 'I';
$tab[3] = 'O';
$tab[4] = 'U';
$tab[5] = 'Y';

?>