<?php
/*
Soit T un tableau de N réels. Ecrire un algorithme qui permet de calculer le nombre des occurrences d'un nombre X 
(c'est-à-dire combien de fois ce nombre X figure dans le tableau T).
*/


// on entre un tableau et ses valeurs
$tab = array(14,3,8,45,12,258,3,45,9,2,5,14,3,8,45,12,258,3,45,9,2,5);

$nb = read
?>